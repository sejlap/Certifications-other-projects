﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvioPrevoz
{
    public class Domaci: Klijenti
    {
   public Domaci(string ime, string prezime, DateTime datumrodjenja, int id): base(ime, prezime,datumrodjenja,id)
        {

        }
        
    }
}

